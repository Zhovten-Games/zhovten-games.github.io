# Canon Horror Series 1 / Canon Horror: серія 1 / Канон Хоррор: серия 1

This directory contains the source materials and publication files for **Language as Infection and the Systems of Horror** — a trilingual archived working-paper package.

Цей каталог містить вихідні матеріали й публікаційні файли для **Мова як зараження та системи горору** — тримовного архівного пакета робочих статей.

Этот каталог содержит исходные материалы и публикационные файлы для **Язык как заражение: медиальная коммуникация как механизм поражения** — трёхъязычного архивного пакета рабочих статей.

**Archive:** https://doi.org/10.5281/zenodo.19773963

**Build pipeline:** https://github.com/Zhovten-Games/zg-journal-template

> The materials are published as working papers / preprints and are not peer reviewed.
>
> Матеріали опубліковано як working papers / preprints; вони не проходили рецензування.
>
> Материалы опубликованы как working papers / preprints и не проходили рецензирование.

---

<details open>
<summary><strong>English</strong></summary>

## About

**Language as Infection and the Systems of Horror** is a trilingual working-paper package centered on the idea of language, perception, and media channels as systems of vulnerability in modern horror and science fiction.

This publication emerged from internal development discussions at Zhovten Games. It is a companion research output to the studio’s practical work, focused on questions of language, perception, horror systems, and narrative design.

The materials are interconnected and refer to one another as parts of a single research corpus. This directory preserves the working structure, sources, and publication context of the archived release.

The PDFs were produced through the **ZG Journal Template** pipeline:

https://github.com/Zhovten-Games/zg-journal-template

## Contents

### 1. Language as Infection — Media Communication as a Mechanism of Harm

The foundational theoretical paper in the series. Within a limited corpus of media works, it shows how the channel of perception — speech, hearing, vision, and signal — itself becomes a vulnerability node and a scenario of subjective harm.

### 2. After the Nuclear Strike — The Transformation of Japanese Horror from Monster to Infected System

This paper traces the Japanese material from a historical strike to long-term cultural regimes of fear: from the monster and bodily mutation to the media and institutional infrastructure of contagion.

### 3. When Disaster Becomes Environment — Chernobyl and the Spatial Model of Horror

This paper develops the Ukrainian spatial model of horror: not a single event, but prolonged life inside a damaged environment where risk is distributed across space, infrastructure, and everyday adaptive practices.

### 4. Viruses and Bioweapons — Infection Mechanics and Media Analogues

This companion working paper separates two analytical registers: the biological register, where a virus is an obligate intracellular parasite with a concrete replication mechanism, and the media register, where “contagion” functions as a transmission protocol through channels of perception.

## Archival note

For citation and long-term access, use the archived Zenodo release linked at the top of this README.

</details>

---

<details>
<summary><strong>Українська</strong></summary>

## Про пакет

**Мова як зараження та системи горору** — тримовний пакет робочих статей про мову, сприйняття й медіальні канали як системи вразливості в сучасному горорі та науковій фантастиці.

Публікація стала результатом внутрішніх обговорень у Zhovten Games. Це дослідницький матеріал, що доповнює практичну роботу студії та зосереджується на питаннях мови, сприйняття, систем горору й наративного дизайну.

Матеріали взаємопов’язані й посилаються один на одного як частини єдиного дослідницького корпусу. Цей каталог зберігає робочу структуру, джерела та публікаційний контекст архівного релізу.

PDF-файли зібрано через конвеєр **ZG Journal Template**:

https://github.com/Zhovten-Games/zg-journal-template

## Склад

### 1. Мова як зараження — медіальна комунікація як механізм ураження

Базова теоретична стаття серії. На матеріалі обмеженого корпусу медіатворів вона показує, як канал сприйняття — мовлення, слух, зір і сигнал — сам стає вузлом уразливості та сценарієм ураження суб’єкта.

### 2. Після ядерного удару — трансформація японського горору від монстра до зараженої системи

Стаття простежує японський матеріал від історичного удару до довготривалих культурних режимів страху: від монстра й тілесної мутації до медіальної та інституційної інфраструктури зараження.

### 3. Коли катастрофа стає середовищем — Чорнобиль і просторова модель горору

Стаття розгортає українську просторову модель горору: тривале життя всередині пошкодженого середовища, де ризик розподілено у просторі, інфраструктурі й повсякденних практиках адаптації.

### 4. Віруси та біозброя — механіки зараження й медіа-аналоги

Документ-компаньйон розмежовує два аналітичні регістри: біологічний, де вірус є облігатним внутрішньоклітинним паразитом із конкретною механікою реплікації, і медіальний, де «зараження» функціонує як протокол передавання через канали сприйняття.

## Архівна примітка

Для цитування й довготривалого доступу використовуйте архівний реліз Zenodo, зазначений на початку README.

</details>

---

<details>
<summary><strong>Русский</strong></summary>

## О пакете

**Язык как заражение: медиальная коммуникация как механизм поражения** — трёхъязычный пакет рабочих статей о языке, восприятии и медиальных каналах как системах уязвимости в современном хорроре и научной фантастике.

Данная публикация стала результатом внутренних обсуждений, прошедших в студии Zhovten Games. Это исследовательский материал, дополняющий практическую работу студии и посвящённый вопросам языка, восприятия, механизмов создания атмосферы ужаса и повествовательного дизайна.

Материалы взаимосвязаны и ссылаются друг на друга как части единого исследовательского корпуса. Этот каталог сохраняет рабочую структуру, исходники и публикационный контекст архивного релиза.

PDF-файлы собраны через пайплайн **ZG Journal Template**:

https://github.com/Zhovten-Games/zg-journal-template

## Состав

### 1. Язык как заражение — медиальная коммуникация как механизм поражения

Базовая теоретическая статья серии. На ограниченном корпусе медиальных произведений она показывает, как канал восприятия — речь, слух, зрение и сигнал — сам становится узлом уязвимости и сценарием поражения субъекта.

### 2. После ядерного удара — трансформация японского ужаса от монстра к заражённой системе

Статья прослеживает японский материал от исторического удара к долговременным культурным режимам страха: от монстра и телесной мутации к медиальной и институциональной инфраструктуре заражения.

### 3. Когда катастрофа становится средой — Чернобыль и пространственная модель ужаса

Статья разворачивает украинскую пространственную модель ужаса: не единичное событие, а длительная жизнь внутри повреждённой среды, где риск распределён в пространстве, инфраструктуре и повседневных практиках адаптации.

### 4. Вирусы и биооружие — механики заражения и медиа-аналоги

Документ-компаньон разделяет два аналитических регистра: биологический, где вирус является облигатным внутриклеточным паразитом с конкретной механикой репликации, и медиальный, где «заражение» функционирует как протокол передачи через каналы восприятия.

## Архивное примечание

Для цитирования и долгосрочного доступа используйте архивный релиз Zenodo, указанный в начале README.

</details>

---

## Suggested citation / Рекомендоване посилання / Рекомендуемая ссылка

**Starling, Sam, and Oksana Dubinetska. _Canon Horror Series: Language as Infection and the Systems of Horror v1.2.0_. Zenodo, 2026. https://doi.org/10.5281/zenodo.19773963**

## License / Ліцензія / Лицензия

Published under the **Creative Commons Attribution-ShareAlike 4.0 International** license.

Опубліковано за ліцензією **Creative Commons Attribution-ShareAlike 4.0 International**.
Опубликовано по лицензии **Creative Commons Attribution-ShareAlike 4.0 International**.
